Database file is found in the database folder. Import it to apache server(phpmyadmin) i.e XAMPP.

Admin section
you add /admin to the end of the link. eg http://localhost:/Vision%20Academy/admin/

Login details is:
email:admin@vision.ac.ke
password: admin